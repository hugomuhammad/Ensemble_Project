import streamlit as st
import numpy as np
import pandas as pd
from sklearn import datasets

def app():
    st.title('Data Page')

    dataset_name = st.sidebar.selectbox("Select Dataset", ("Iris","Breast Cancer","Add file"))

    st.write("Dataframe")

    def get_dataset(dataset_name):
        if dataset_name == "Iris":
            data = datasets.load_iris()
            dataframe = pd.DataFrame(data= np.c_[data['data'], data['target']],
                        columns= data['feature_names'] + ['target'])
            return dataframe

        elif dataset_name == "Breast Cancer":
            cancer = datasets.load_breast_cancer()     
            data = np.c_[cancer.data, cancer.target]
            columns = np.append(cancer.feature_names, ["target"])
            dataframe = pd.DataFrame(data, columns=columns)
            return dataframe


        else:
            uploaded_file = st.file_uploader("Choose a file")
            if uploaded_file is not None:
                dataframe = pd.read_csv(uploaded_file)      
                return dataframe

    df = get_dataset(dataset_name)
    st.write(df)
