import streamlit as st

def app():
    st.title('Home Page')

    st.write('Fafifuwasweswos')

    st.write('Simple Classification App')
