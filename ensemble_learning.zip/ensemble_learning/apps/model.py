import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC
from sklearn import datasets


def app():

    st.title('Model Page')

    dataset_name = st.sidebar.selectbox("Select Dataset", ("Iris","Breast Cancer","Add file"))
    classifier_name = st.sidebar.selectbox("Select Classifier", ("KNN","SVM","Ensemble"))

    def get_dataset(dataset_name):
        if dataset_name == "Iris":
            data = datasets.load_iris()
            dataframe = pd.DataFrame(data= np.c_[data['data'], data['target']],
                        columns= data['feature_names'] + ['target'])
            return dataframe

        elif dataset_name == "Breast Cancer":
            cancer = datasets.load_breast_cancer()     
            data = np.c_[cancer.data, cancer.target]
            columns = np.append(cancer.feature_names, ["target"])
            dataframe = pd.DataFrame(data, columns=columns)
            return dataframe


        else:
            uploaded_file = st.file_uploader("Choose a file")
            if uploaded_file is not None:
                dataframe = pd.read_csv(uploaded_file)      
                return dataframe

    def select_feature_target(dataset, dataset_name):
        if dataset_name == "Add file":
            dataframe = dataset
            lst = []
            for i in range (len(dataframe.columns)):
                if dataframe[dataframe.columns[i]].dtype == "object":
                    lst.append(i)
                else:
                    pass
            dataframe = dataframe.drop(dataframe.columns[lst], axis=1)
            X = dataframe.iloc[:,:-1]
            y = dataframe.iloc[:,-1:]
            return dataframe, X, y

        elif dataset_name == "Iris" or "Breast Cancer":
            dataframe = dataset
            X = dataset.iloc[:,:-1]
            y = dataset.iloc[:,-1]
            return dataframe, X, y


    data = get_dataset(dataset_name)
    st.write(data)

    data, X, y = select_feature_target(data, dataset_name)
    st.markdown("## Feature dan Target")
    st.write('Feature',list(data.iloc[:,:-1].keys()))
    st.write('Target',list(data.iloc[:,-1:].keys()))

    def add_parameter_ui(clf_name):
        params = dict()
        if clf_name == 'SVM':
            C = st.sidebar.slider('C', 0.01, 10.0)
            params['C'] = C
        elif clf_name == 'KNN':
            K = st.sidebar.slider('K', 1, 15)
            params['K'] = K
        else:
            K = st.sidebar.slider('Input K', 1, 15)
            params['K'] = K
            C = st.sidebar.slider('Input C', 0.01, 10.0)
            params['C'] = C
        return params

    params = add_parameter_ui(classifier_name)

    def get_classifier(clf_name, params):
        clf = None
        if clf_name == 'SVM':
            clf = SVC(C=params['C'])
        elif clf_name == 'KNN':
            clf = KNeighborsClassifier(n_neighbors=params['K'])
        else:
            knn = KNeighborsClassifier(n_neighbors=params['K'])
            svm = SVC(kernel = 'poly', degree = 2 )
            clf = VotingClassifier( estimators= [('knn',knn),('svm',svm)], voting = 'hard')
        return clf

    clf = get_classifier(classifier_name, params)

    def get_result(clf,clf_name,X,y):
        if clf_name == 'SVM':
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=1234)
            clf.fit(X_train, y_train)
            y_pred = clf.predict(X_test)
            acc = accuracy_score(y_test, y_pred)

        elif clf_name == 'KNN':
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=1234)
            clf.fit(X_train, y_train)
            y_pred = clf.predict(X_test)
            acc = accuracy_score(y_test, y_pred)
        
        else:
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=1234)
            clf.fit(X_train, y_train)
            
            st.markdown("## Tujuan")
            display = ("Test Data", "Prediksi data")
            options = list(range(len(display)))
            value = st.selectbox("Pilih Tujuan", options, format_func=lambda x: display[x])

            if value == "Prediksi data":
                st.markdown('## Input Data Prediksi')
                input_file = st.file_uploader("choose a file")
                if input_file is not None:
                    dataframe = pd.read_csv(input_file)      
                
                st.write(dataframe)
                lst = []
                for i in range (len(dataframe.columns)):
                    if dataframe[dataframe.columns[i]].dtype == "object":
                        lst.append(i)
                X_test = dataframe.drop(dataframe.columns[lst], axis=1)
                y_pred = clf.predict(X_test)
                acc = "Hasil Prediksi"
            
            else:
                y_pred = clf.predict(X_test)
                acc = accuracy_score(y_test, y_pred)
                        
        
        return X_test, y_test ,y_pred, acc
            

    X_test, y_test, y_pred, acc = get_result(clf, classifier_name, X, y)

    st.markdown("## Hasil Prediksi")
    st.write(f'Classifier = {classifier_name}')
    st.write(f'Accuracy =', acc)

    st.write('Dataframe')
    X_test['Target'] = y_pred
    res =  X_test
    st.write(res)
